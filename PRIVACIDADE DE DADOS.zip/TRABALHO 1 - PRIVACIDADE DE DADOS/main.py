import pandas as pd
import numpy as np
from collections import Counter
import matplotlib.pyplot as plt
import seaborn as sns
from itertools import product
import copy


class KAnonimatoLDiversidade:
    """
    Implementação de K-Anonimato e L-Diversidade
    para dados de COVID-19 do Ceará
    """

    def __init__(self, df):
        self.original_df = df.copy()
        self.df = df.copy()
        self.hierarquias = self.construir_hierarquias()
        self.semi_identificadores = ['localidade', 'data_nascimento']
        self.atributo_sensivel = 'raca_cor'

    def construir_hierarquias(self):
        #constrói hierarquias de generalização para os semi-identificadores
        hierarquias = {
            'data_nascimento': {
                0:
                lambda x: x,  # dd/mm/aaaa (original)
                1:
                lambda x: f"*/{x.split('/')[1]}/{x.split('/')[2]}"
                if len(x.split('/')) >= 3 else x,  # */mm/aaaa
                2:
                lambda x: f"*/*/{x.split('/')[2]}"
                if len(x.split('/')) >= 3 else x,  # */*/aaaa
                3:
                lambda x: self._generalizar_faixa_ano(x.split('/')[-1])
                if len(x.split('/')) >= 3 else x,  # faixas de 5 anos
                4:
                lambda x: self._generalizar_decada(x.split('/')[-1])
                if len(x.split('/')) >= 3 else x,  # décadas
                5:
                lambda x: self._generalizar_geracao(x.split('/')[-1])
                if len(x.split('/')) >= 3 else x  # gerações
            },
            'localidade': {
                0:
                lambda x: x,  # bairro/cidade/estado (original)
                1:
                lambda x: f"*/{x.split('/')[1]}/{x.split('/')[2]}"
                if len(x.split('/')) >= 3 else x,  # */cidade/estado
                2:
                lambda x: f"*/*/{x.split('/')[2]}"
                if len(x.split('/')) >= 3 else x,  # */*/estado
                3:
                lambda x: self._generalizar_tamanho_cidade(x)
                if len(x.split('/')) >= 3 else x,  # por tamanho da cidade
                4:
                lambda x: self._generalizar_regiao(x.split('/')[2])
                if len(x.split('/')) >= 3 else x  # por região
            }
        }
        return hierarquias

    def _generalizar_faixa_ano(self, ano_str):
        #generaliza anos em faixas de 5 anos
        try:
            ano = int(ano_str)
            inicio_faixa = (ano // 5) * 5
            return f"{inicio_faixa}-{inicio_faixa + 4}"
        except:
            return ano_str

    def _generalizar_decada(self, ano_str):
        #generaliza anos em décadas
        try:
            ano = int(ano_str)
            decada = (ano // 10) * 10
            return f"{decada}s"
        except:
            return ano_str

    def _generalizar_geracao(self, ano_str):
        #generaliza por gerações
        try:
            ano = int(ano_str)
            if ano >= 1997:
                return "Gen Z (1997+)"
            elif ano >= 1981:
                return "Millennial (1981-1996)"
            elif ano >= 1965:
                return "Gen X (1965-1980)"
            elif ano >= 1946:
                return "Baby Boomer (1946-1964)"
            else:
                return "Silent Gen (1928-1945)"
        except:
            return ano_str

    def _generalizar_tamanho_cidade(self, localidade):
        #generaliza cidades por tamanho populacional
        partes = localidade.split('/')
        if len(partes) >= 3:
            cidade = partes[1].upper()
            grandes_cidades = [
                'FORTALEZA', 'CAUCAIA', 'JUAZEIRO DO NORTE', 'MARACANAÚ',
                'SOBRAL'
            ]
            if cidade in grandes_cidades:
                return f"*/{cidade}/{partes[2]} (Grande)"
            else:
                return f"*/Outras/{partes[2]}"
        return localidade

    def _generalizar_regiao(self, estado):
        #generaliza estados por região
        regioes = {
            'CE': 'Nordeste',
            'BA': 'Nordeste',
            'PE': 'Nordeste',
            'RN': 'Nordeste',
            'PB': 'Nordeste',
            'AL': 'Nordeste',
            'SE': 'Nordeste',
            'MA': 'Nordeste',
            'PI': 'Nordeste',
            'SP': 'Sudeste',
            'RJ': 'Sudeste',
            'MG': 'Sudeste',
            'ES': 'Sudeste',
            'PR': 'Sul',
            'SC': 'Sul',
            'RS': 'Sul',
            'GO': 'Centro-Oeste',
            'MT': 'Centro-Oeste',
            'MS': 'Centro-Oeste',
            'DF': 'Centro-Oeste',
            'AM': 'Norte',
            'PA': 'Norte',
            'AC': 'Norte',
            'RO': 'Norte',
            'RR': 'Norte',
            'AP': 'Norte',
            'TO': 'Norte'
        }
        return regioes.get(estado, 'Outras Regiões')

    def obter_nivel_generalizacao(self, valor, atributo):
        #determina o nível de generalização de um valor
        if pd.isna(valor):
            return 0

        valor_str = str(valor)

        if atributo == 'data_nascimento':
            if 'Gen' in valor_str or 'Millennial' in valor_str or 'Boomer' in valor_str:
                return 5
            elif valor_str.endswith('s'):
                return 4
            elif '-' in valor_str:
                return 3
            elif valor_str.startswith('*/*'):
                return 2
            elif valor_str.startswith('*/'):
                return 1
            else:
                return 0
        elif atributo == 'localidade':
            if valor_str in [
                    'Nordeste', 'Sudeste', 'Sul', 'Centro-Oeste', 'Norte'
            ]:
                return 4
            elif 'Grande' in valor_str or 'Outras' in valor_str:
                return 3
            elif valor_str.startswith('*/*'):
                return 2
            elif valor_str.startswith('*/'):
                return 1
            else:
                return 0
        return 0

    def aplicar_generalizacao(self, df, vetor_generalizacao):
        #aplica um vetor de generalização ao dataset
        df_gen = df.copy()

        #remove identificadores explícitos
        if 'nome' in df_gen.columns:
            df_gen['nome'] = '*'
        if 'cpf' in df_gen.columns:
            df_gen['cpf'] = '*'

        #aplica generalização aos semi-identificadores
        for i, attr in enumerate(self.semi_identificadores):
            nivel = vetor_generalizacao[i]
            if nivel > 0 and attr in df_gen.columns:
                df_gen[attr] = df_gen[attr].apply(lambda x: self.hierarquias[attr][nivel](str(x)) if not pd.isna(x) else x)

        return df_gen

    def obter_classes_equivalencia(self, df):
        #obtém as classes de equivalência baseadas nos semi-identificadores
        colunas_faltantes = [col for col in self.semi_identificadores if col not in df.columns]
        if colunas_faltantes:
            print(f"ERRO: Colunas não encontradas: {colunas_faltantes}")
            return []

        df_limpo = df.dropna(subset=self.semi_identificadores)

        if len(df_limpo) == 0:
            return []

        grupos = df_limpo.groupby(self.semi_identificadores)
        return [grupo for nome, grupo in grupos]

    def verificar_k_anonimato(self, classes_equivalencia, k):
        #erifica se as classes de equivalência satisfazem k-anonimato
        if not classes_equivalencia:
            return False
        tamanho_min = min(len(classe) for classe in classes_equivalencia)
        return tamanho_min >= k

    def verificar_l_diversidade(self, classes_equivalencia, l):
        #verifica se as classes de equivalência satisfazem l-diversidade
        if not classes_equivalencia:
            return False

        for classe in classes_equivalencia:
            if self.atributo_sensivel not in classe.columns:
                return False
            valores_unicos = classe[self.atributo_sensivel].nunique()
            if valores_unicos < l:
                return False
        return True

    def calcular_precisao(self, df_anonimizado):
        #calcula a precisão do dataset anonimizado
        N = len(df_anonimizado)
        M = len(self.semi_identificadores)

        perda_total = 0
        niveis_maximos = {'data_nascimento': 5, 'localidade': 4}

        for i in range(N):
            for j, attr in enumerate(self.semi_identificadores):
                if attr in df_anonimizado.columns:
                    valor = df_anonimizado.iloc[i][attr]
                    nivel = self.obter_nivel_generalizacao(valor, attr)
                    profundidade = niveis_maximos[attr]
                    perda_total += nivel / profundidade

        perda_info = perda_total / (N * M)
        precisao = 1 - perda_info

        return precisao

    def encontrar_melhor_generalizacao(self, k, l):
        #encontra a generalização ótima para k=2, l=2
        print("Iniciando busca pela generalização ótima...")

        #gera combinações ordenadas por nível de generalização
        niveis_data = list(range(6))  # 0 a 5
        niveis_local = list(range(5))  # 0 a 4

        combinacoes = []
        for nivel_data in niveis_data:
            for nivel_local in niveis_local:
                nivel_total = nivel_data + nivel_local
                combinacoes.append((nivel_total, [nivel_data, nivel_local]))

        combinacoes.sort(key=lambda x: x[0])

        melhor_solucao = None
        melhor_precisao = -1

        for nivel_total, vetor in combinacoes:
            print(
                f"Testando vetor de generalização {vetor} (nível total: {nivel_total})"
            )

            try:
                df_gen = self.aplicar_generalizacao(self.df, vetor)
                classes_eq = self.obter_classes_equivalencia(df_gen)

                if not classes_eq:
                    continue

                tamanhos = [len(classe) for classe in classes_eq]
                tamanho_min = min(tamanhos)
                k_satisfeito = tamanho_min >= k

                print(
                    f"  Classes: {len(classes_eq)}, Tamanho mínimo: {tamanho_min}, K-anonimato: {k_satisfeito}"
                )

                if not k_satisfeito:
                    continue

                l_satisfeito = self.verificar_l_diversidade(classes_eq, l)
                print(f"  L-diversidade: {l_satisfeito}")

                if k_satisfeito and l_satisfeito:
                    precisao = self.calcular_precisao(df_gen)
                    print(f"  Precisão: {precisao:.4f}")

                    if precisao > melhor_precisao:
                        melhor_precisao = precisao
                        melhor_solucao = (df_gen, classes_eq, vetor, precisao)
                        print(f"  Nova melhor solução encontrada!")

                    if precisao > 0.5:
                        print(
                            f"  Precisão satisfatória alcançada. Finalizando busca."
                        )
                        break

            except Exception as e:
                print(f"  Erro ao testar {vetor}: {e}")
                continue

        if melhor_solucao:
            return melhor_solucao
        else:
            print("Nenhuma solução encontrada!")
            return None, None, None, None

    def criar_histograma_classes_equivalencia(self, classes_eq, k, top_y=15):
        #cria histograma das top-y maiores classes de equivalência
        if not classes_eq:
            return

        tamanhos = [len(classe) for classe in classes_eq]
        tamanhos.sort(reverse=True)

        top_tamanhos = tamanhos[:min(top_y, len(tamanhos))]

        plt.figure(figsize=(12, 6))
        plt.bar(range(1, len(top_tamanhos) + 1),
                top_tamanhos,
                color='skyblue',
                edgecolor='navy')
        plt.xlabel('Ranking das Classes de Equivalência')
        plt.ylabel('Tamanho da Classe')
        plt.title(f'Top {min(top_y, len(tamanhos))} Maiores Classes de Equivalência (k={k})')
        plt.grid(axis='y', alpha=0.3)

        for i, tamanho in enumerate(top_tamanhos):
            plt.text(i + 1, tamanho + 0.5, str(tamanho), ha='center', va='bottom')

        plt.tight_layout()
        plt.savefig(f'classes_equivalencia_histograma_k{k}.png', dpi=300, bbox_inches='tight')
        plt.show()

    def criar_histograma_l_diversidade(self, classes_eq, l):
        #cria histograma da diversidade do atributo sensível
        if not classes_eq:
            return

        contagens_diversidade = []
        for classe in classes_eq:
            if self.atributo_sensivel in classe.columns:
                valores_unicos = classe[self.atributo_sensivel].nunique()
                contagens_diversidade.append(valores_unicos)

        frequencia = Counter(contagens_diversidade)

        plt.figure(figsize=(10, 6))
        x_vals = sorted(frequencia.keys())
        y_vals = [frequencia[x] for x in x_vals]

        barras = plt.bar(x_vals, y_vals, color='lightcoral', edgecolor='darkred')
        plt.xlabel('Número de Valores Distintos do Atributo Sensível')
        plt.ylabel('Frequência das Classes de Equivalência')
        plt.title(f'Distribuição da L-Diversidade (l={l})')
        plt.grid(axis='y', alpha=0.3)

        #adiciona valores na barra
        for barra, valor in zip(barras, y_vals):
            plt.text(barra.get_x() + barra.get_width() / 2,
                     barra.get_height() + 0.5,
                     str(valor),
                     ha='center',
                     va='bottom')

        plt.tight_layout()
        plt.savefig(f'l_diversidade_histograma_l{l}.png', dpi=300, bbox_inches='tight')
        plt.show()

    def salvar_resultados_excel(self, classes_eq, k, l, precisao, vetor):
        #salva os resultados em planilha Excel
        if not classes_eq:
            return

        #análise das classes de equivalência
        tamanhos = [len(classe) for classe in classes_eq]

        #análise da diversidade
        contagens_diversidade = []
        for classe in classes_eq:
            if self.atributo_sensivel in classe.columns:
                valores_unicos = classe[self.atributo_sensivel].nunique()
                contagens_diversidade.append(valores_unicos)

        #cria dataframes para salvar
        resumo = {
            'Métrica': [
                'Valor de k', 'Valor de l', 'Precisão',
                'Vetor de Generalização', 'Total de Classes', 'Tamanho Médio',
                'Tamanho Mínimo', 'Tamanho Máximo'
            ],
            'Valor': [
                k, l, f"{precisao:.4f}",
                str(vetor),
                len(classes_eq), f"{np.mean(tamanhos):.2f}",
                min(tamanhos),
                max(tamanhos)
            ]
        }

        dados_tamanhos = {
            'Classe': range(1, len(tamanhos) + 1),
            'Tamanho': sorted(tamanhos, reverse=True)
        }

        freq_div = Counter(contagens_diversidade)
        dados_diversidade = {
            'Valores_Distintos': list(freq_div.keys()),
            'Frequencia': list(freq_div.values())
        }

        #salva em excel
        nome_arquivo = f'resultados_k{k}_l{l}.xlsx'
        with pd.ExcelWriter(nome_arquivo, engine='openpyxl') as writer:
            pd.DataFrame(resumo).to_excel(writer, sheet_name='Resumo', index=False)
            pd.DataFrame(dados_tamanhos).to_excel(writer, sheet_name='Tamanhos_Classes', index=False)
            pd.DataFrame(dados_diversidade).to_excel(writer, sheet_name='L_Diversidade', index=False)

        print(f"Resultados salvos em: {nome_arquivo}")

    def executar_anonimizacao(self, k=2, l=2):
        #executa o processo de anonimização
        print(f"{'='*60}")
        print(f"PROCESSO DE ANONIMIZAÇÃO - k={k}, l={l}")
        print(f"{'='*60}")

        resultado = self.encontrar_melhor_generalizacao(k, l)

        if resultado[0] is None:
            print("Falha na anonimização!")
            return None

        df_anon, classes_eq, vetor, precisao = resultado

        print(f"\n{'='*60}")
        print("RESULTADO FINAL")
        print(f"{'='*60}")
        print(f"Vetor de generalização: {vetor}")
        print(f"Precisão: {precisao:.4f}")
        print(f"Classes de equivalência: {len(classes_eq)}")

        tamanhos = [len(classe) for classe in classes_eq]
        print(f"Tamanho médio das classes: {np.mean(tamanhos):.2f}")
        print(f"Tamanho mínimo: {min(tamanhos)}")
        print(f"Tamanho máximo: {max(tamanhos)}")

        #salva dataset anonimizado
        nome_csv = f"dados_covid_ce_anonimizado_k{k}_l{l}.csv"
        df_anon.to_csv(nome_csv, sep=';', index=False)
        print(f"Dataset anonimizado salvo como: {nome_csv}")

        #criar visualizações e salva resultados
        self.criar_histograma_classes_equivalencia(classes_eq, k)
        self.criar_histograma_l_diversidade(classes_eq, l)
        self.salvar_resultados_excel(classes_eq, k, l, precisao, vetor)

        return df_anon, classes_eq, precisao


def main():
    try:
        #carrega os dados
        df = pd.read_csv('dados_covid-ce_02.csv', sep=';')
        print("Dataset carregado com sucesso!")
        print(f"Formato: {df.shape}")
        print(f"Colunas: {list(df.columns)}")

        #cria o objeto de anonimização
        anonimizador = KAnonimatoLDiversidade(df)

        #executa anonimização para k=2, l=2
        print(f"\n{'#'*80}")
        print(f"EXECUTANDO ANONIMIZAÇÃO PARA k=8, l=4")
        print(f"{'#'*80}")

        resultado = anonimizador.executar_anonimizacao(k=8, l=4)

        if resultado:
            print("\nProcesso de anonimização concluído com sucesso!")
        else:
            print("\nFalha no processo de anonimização.")

    except FileNotFoundError:
        print("Erro!")
    except Exception as e:
        print(f"Erro inesperado: {e}")


if __name__ == "__main__":
    main()