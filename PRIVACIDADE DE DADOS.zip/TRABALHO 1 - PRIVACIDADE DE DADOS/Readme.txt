Trabalho 01 - k-Anonimato e l-Diversidade
Disciplina: Privacidade de Dados

Docente: ANDRÉ LUÍS DA COSTA MENDONÇA

Discentes:
ANTONIA RAFAELA MOREIRA DA COSTA
ITALO RUAN MENESES DA COSTA
THIAGO QUEIROZ DA SILVA


Descrição do trabalho:
O presente trabalho tem como objetivo aplicar técnicas de anonimização de dados pessoais por meio dos modelos de K-Anonimato e L-Diversidade, utilizando dados reais da COVID-19 no estado do Ceará para:
- Reduzir o risco de identificação de indivíduos via generalização de atributos;
- Garantir diversidade de valores sensíveis (raça/cor) dentro de cada classe de equivalência.


Dataset utilizado:
Arquivo original: dados_covid-ce.csv  
Fonte: https://tinyurl.com/unilab-priv-dados-covid-ce  

Atributos:
- Identificadores explícitos: nome, cpf
- Semi-identificadores: localidade, data_nascimento
- Sensível: raca_cor


Funcionamento do código:
O programa está implementado em Python e possui as seguintes etapas:
- Generalização dos atributos `data_nascimento` e `localidade` em diferentes níveis;
- Remoção de identificadores explícitos;
- Geração de classes de equivalência com base nos semi-identificadores;
- Aplicação dos critérios de K-Anonimato (k ∈ {2, 4, 8}) e L-Diversidade (l ∈ {2, 3, 4});
- Cálculo de métricas: precisão, tamanho médio das classes, diversidade;
- Geração de gráficos: histograma de classes de equivalência e histograma de l-diversidade;
- Salvamento dos dados anonimizados em arquivos .csv e resultados em .xlsx.